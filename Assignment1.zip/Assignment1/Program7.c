/*

    Accept from user number and print even number

*/

